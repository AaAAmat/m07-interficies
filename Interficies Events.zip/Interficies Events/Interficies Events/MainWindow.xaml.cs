﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;

namespace Interficies_Events
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void bt1_Click(object sender, RoutedEventArgs e)
        {

            Debug.WriteLine("CMD: clic 1");
            MessageBox.Show("Clic 1");

            // para la propagació
            //e.Handled = true;
        }

        private void bt2_Click(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("CMD: clic 2");
            MessageBox.Show("Clic 2");
           
        }

       
        private void bt3_Click(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("CMD: clic 3");
            MessageBox.Show("Clic 3");
        }



        

        private void StackPanel_Click_1(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("StackPanel clicat");
            e.Handled = true;
        }

        private void StackPanel_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}